<?php
define('HOST','localhost');
define('USER','root');
define('PASS','');
define('DB','mydb');
 

$device_id_val = $_POST['temperature'];
$on_off_db = $_POST['humidity'];
			
echo $_POST['temperature']." ".$_POST['humidity'];

$myfile = fopen("profile_to_MC.txt", "w") or die("Unable to open file!");
$txt = "t:".$_POST['temperature'].",h:".$_POST['humidity'];
fwrite($myfile, $txt);
fclose($myfile);




?>
