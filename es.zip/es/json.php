<?php
define('HOST','localhost');
define('USER','root');
define('PASS','');
define('DB','Power');
 
$con = mysqli_connect(HOST,USER,PASS,DB);
 
$sql = "select * from Measurement";
 
$res = mysqli_query($con,$sql);
 
$result = array();
 
while($row = mysqli_fetch_array($res)){
array_push($result,
array('id'=>$row[0],
'Voltage'=>$row[1],
'Current'=>$row[2]
));
}
 
echo json_encode(array("result"=>$result));
 
mysqli_close($con);
 
?>
