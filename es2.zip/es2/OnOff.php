<?php
define('HOST','localhost');
define('USER','root');
define('PASS','');
define('DB','mydb');
 

$device_id_val = $_POST['device_id'];
$on_off_db = $_POST['on_off'];
			
echo $_POST['device_id']." ".$_POST['on_off'];

$myfile = fopen("input_to_MC.txt", "w") or die("Unable to open file!");
$txt = "id:".$_POST['device_id'].",onoff:".$_POST['on_off'];
fwrite($myfile, $txt);
fclose($myfile);




?>
