<?php
define('HOST','localhost');
define('USER','root');
define('PASS','');
define('DB','mydb');

if($_SERVER['REQUEST_METHOD']=='POST')
{

	ini_set('max_execution_time', 0);
	ini_set('memory_limit', '256M');
		$device_id_val = $_POST['device_id_val'];
		$on_off_db = $_POST['on_off_db'];
		$date = $_POST['date'];
		$time_db = $_POST['time_db'];
		$milliseconds = $_POST['milliseconds'];
		
			
	// echo $_POST['device_id_val'];
	// echo $_POST['on_off_db'];
	// echo $_POST['date'];
	// echo $_POST['time_db'];
	// echo $_POST['milliseconds'];

	$con = mysqli_connect(HOST,USER,PASS,DB);

	$sql = "INSERT INTO Timers (device_id,device_name,milliseconds,date,time,on_off) VALUES ('$device_id_val','Lightz','$milliseconds','$date','$time_db','$on_off_db')";

	if(mysqli_query($con,$sql))
	{
		echo "Successfully Registered";
	}
	else
	{
		echo "Could not register";
	}

	$base = new EventBase();
	$currmillis = round(microtime(true) * 1000);
	$n = ($_POST['milliseconds']-$currmillis)/1000;
	$myfile = fopen("timer.txt", "w") or die("Unable to open file!");
	$txt = "timer set on $device_id_val and it goes off in $n seconds \n";
	fwrite($myfile, $txt);
	fclose($myfile);
	$e = Event::timer($base, function($n) use (&$e) {
	//echo "$n seconds elapsed\n";
	$myfile = fopen("timer.txt", "w") or die("Unable to open file!");
	$txt = "$n seconds elapsed\n";
	fwrite($myfile, $txt);
	fclose($myfile);
	$e->delTimer();
	}, $n);
	$e->addTimer($n);
	$base->loop();
}
else
{
	echo 'error';
}

?>
