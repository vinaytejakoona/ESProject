<?php
ini_set('max_execution_time', 0);
ini_set('memory_limit', '256M');
$base = new EventBase();
echo "e";
$n = 10;
$e = Event::timer($base, function($n) use (&$e) {
   //echo "$n seconds elapsed\n";
    $myfile = fopen("timer.txt", "w") or die("Unable to open file!");
	$txt = "$n seconds elapsed\n";
	fwrite($myfile, $txt);
	fclose($myfile);
    $e->delTimer();
}, $n);
$e->addTimer($n);
$base->loop();
?>

